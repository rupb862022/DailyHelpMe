﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication.Dto
{
    public class Location
    {
        public string Lat {get;set;}
        public string Lng { get; set;}
        public string CityName { get; set;}

    }
}