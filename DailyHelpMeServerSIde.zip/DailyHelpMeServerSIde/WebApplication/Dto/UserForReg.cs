﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication.Dto
{
    public class UserForReg
    {
        public string Email { get; set; }
        public string Passwords { get; set; }
    }
}